import java.io.*;
public class Hoppity
{
	public static void main(String[] args) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedReader readr = new BufferedReader(new FileReader(args[0]));
		String strnum=readr.readLine();
		String finnum="";
		for(int i=0;i<strnum.length();i++)
		{
			if(strnum.charAt(i)>='0' && strnum.charAt(i)<='9')
				finnum=finnum+strnum.charAt(i);
		}
		int num=Integer.parseInt(finnum);
		for(int j=1;j<=num;j++)
		{
			if(j%3==0)
			{
				if(j%5==0)
					System.out.println("Hop");
				else
					System.out.println("Hoppity");
			}
			else if(j%5==0)
				System.out.println("Hophop");
		}
	br.readLine();
	}
}